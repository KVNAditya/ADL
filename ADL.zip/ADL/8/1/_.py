# import torch
# import dill

# dil__nn__01 = '__/0/_01_.dil'
# _01_ = dill.load(open(dil__nn__01, 'rb'))
# # print(_01_)

# io__sudo_urls = ['https://www.ads.osborne-reed.com/1cAaFmv035HoZ9nSWRWXJtWkBIfG5MYgk0nbvgjzGPOlwc?param_1=vJhy50oDhJasy5NVQBNKsPqGAir4PELDjl6dNrVmHyOfaP6ZrZyzr3S4GYrtA2Af0F4l&param_2=KuOWwtWMs9240vgstoozDPa&param_3=2Unl94jxXMmsfvh4GbXDjM0xlypuDr2LKV1Hg0glYXmk8CHNzkfl01u1d8jeGUGHK5Jc&param_4=88iC2xXyTVoFSKDwaxYv5Mxj9DuMJbQoUgSBLanTdWFZ4RU8knp1&param_5=CDjwkVd1oiiPsyIxAl8tb45jsCh3zmcE1vZKNfEhymnQCMt8ymQo2um9AeqDxRtbqapPG7T&param_6=KnjBrVDOcqZraIaJF1ZeiBLJUSefsn3fXyLlDOCFnUQRSlAGKxWoJmcuxuCFt6X3iG&param_7=inRZZWq34ZrbSwHC2aJGNCgSAM9548mdFm&param_8=DKSyOPQdHux3kKpQnX6e4GJu9S2KIYbWSZQBc2QAav04bojFPgbt2HC']
# io__sudo_cord_x  = [173409]
# io__sudo_cord_y = [625179]

# io__sudo_urls = torch.tensor([[ord(p) for p in io] + [(-1)*len(io)]*(862 - len(io)) for io in io__sudo_urls]).to(torch.float).squeeze(0).cuda(torch.cuda.current_device())
# io__sudo_cord_x = torch.tensor(io__sudo_cord_x).cuda(torch.cuda.current_device())
# io__sudo_cord_y = torch.tensor(io__sudo_cord_y).cuda(torch.cuda.current_device())
# io__sudo_cords = torch.stack((io__sudo_cord_x,io__sudo_cord_y),dim=1).squeeze(0).cuda(torch.cuda.current_device())

# with torch.no_grad():
#     ipo0 = _01_.__8__(ip=[io__sudo_urls, io__sudo_cords])

# print(ipo0)

# import pandas as pd
# import pickle as pkl
# import matplotlib.pyplot as plt
# from matplotlib.ticker import MaxNLocator
# import mpld3
# # Initialize an empty DataFrame
# df = pd.DataFrame({'urls': [], 'cords': []})

# # Append rows to the DataFrame
# # df = pd.DataFrame({'urls': 'url0', 'cords': (0, 0)}, ignore_index=True)
# df = df._append({'urls': 'url1', 'cords': (1, 1)}, ignore_index=True)
# df = df._append({'urls': 'url2', 'cords': (2, 2)}, ignore_index=True)

# df.loc[len(df)] = ['url3',(3,3)]

# # Print the DataFrame
# print(df)


# import pandas as pd

# io_p_pklio1uc = '__/0/io_1__urls_cords.pkl'

# pd_pkl__io1uc = pd.DataFrame({"urls":['url'],"cords":[(0,0)]})
# pd.to_pickle(pd_pkl__io1uc,io_p_pklio1uc)
# pd_pkl__io1uc = pd.read_pickle(io_p_pklio1uc).to_dict(orient='list')

# pd_pkl__io1uc['urls'] += ['urls']
# pd_pkl__io1uc['cords'] += [(0,10)]

# pd_pkl__io1uc = pd.DataFrame.from_dict(pd_pkl__io1uc,orient='columns')

# qry = pd_pkl__io1uc.loc[(pd_pkl__io1uc['urls']=='url') & (pd_pkl__io1uc['cords']==(0,0))]
# print(qry)

# u0 = "http://www.ads.hall-smith.com/DJ1Z8GHvTLM4Gk9QInFq1AnVK4O0bU2o6BfCK003qm?param_1=SY1eVIULjMSrUdMWlrVbJMD6kJft3lqnqagb2HhcVAZnAqgYMNWjx93MUDOMHzMzxCexWXFh&param_2=1X6snsBXUxmfgHCZ4KYLJ5D9d5HWOz39cpdehUGYDixzLNlHpAPyDSKJYxt18b03bJQ8BA0ikFNzU&param_3=wBG11ph4Mu8PLL8XgtghR96RS7HlpIRpwgtIc3EIJXpjPZQG5dN9hZ4WeeOnQUqIr3&param_4=6iiwkPKrN9GFyxDPmGIbzjVwgzl1SysplfHa4R5S7vyekwjR25v&param_5=NQy0DSch88vYfHSM9pjhzo6wf0jDXv&param_6=rZrCpZbhrk4hj0mpNtTfzY0BpfVWmGzVVEBBsaCxNMb1egF0qeoccykj0TGusQq9Yin"
# u1 = "https://mediaoptions.com/brokered-domains/kennedy-com/W0QhAdst4qBHru7XrGyNsg8xCVnEOkfnWEtTxIUwEEFCnQZ?param_1=wdBJD7MbhVtfeCDNCLLipeMFlpNH4RSTnZewpQS9lXrprLFpXcGM8&param_2=AH1jzpxrbu91lqM9cR6qn9YkU0ruykPiDM7YBtCdsfr8ZYTIjDTfOb9OAvtZX3gjMCj0uHMo3l8&param_3=xS1b79Q5o5U2PJEHisPb6Lpi9jHbf9sBSeqiN2YpLI&param_4=mDGwvDba6AXLa3QphBgw45&param_5=8gSyiKg4LHV78HU2f7t93PavjSJpA0hIDInIPKts1f2qcu7QrMf8u&param_6=c10szp7WDb2mlCqSSyYm8XvN5qj3OG214zwMDBnKB4rFiybAVQ"

# c0 = (547288, 656473)
# c1 = (644217, 832205)


# io_p_pklio0uc = open('__/0/io_0__urls_cords.pkl','rb')

# p = pkl.load(io_p_pklio0uc)

# pd_io_io0uc = pd.DataFrame({'urls':[],'cords':[],'is_clfd':[]}).to_dict(orient='list')

# for i in range(2):
#     pd_io_io0uc['urls'] += [p[i][0]]
#     pd_io_io0uc['cords'] += [p[i][1]]
#     pd_io_io0uc['is_clfd'] += [p[i][2]]

# pd_io_io0uc = pd.DataFrame.from_dict(pd_io_io0uc,orient='columns')

# io_0 = pd_io_io0uc.loc[(pd_io_io0uc['urls']==u0) & (pd_io_io0uc['cords']==(c0[0],c0[1]))]['is_clfd'].to_list()
# io_1 = pd_io_io0uc.loc[(pd_io_io0uc['urls']==u1) & (pd_io_io0uc['cords']==(c1[0],c1[1]))]['is_clfd'].to_list()


# plt.plot(list(pd_io_io0uc.index[pd_io_io0uc['is_clfd'] == 0]), list(pd_io_io0uc[pd_io_io0uc['is_clfd'] == 0]['is_clfd']), 'go', label='is_clfd=0')
# plt.plot(list(pd_io_io0uc.index[pd_io_io0uc['is_clfd'] == 1]), list(pd_io_io0uc[pd_io_io0uc['is_clfd'] == 1]['is_clfd']), 'ro', label='is_clfd=1')
# plt.xticks(pd_io_io0uc.index)
# plt.yticks(pd_io_io0uc['is_clfd'])
# plt.xlabel('index :: [urls,cords]')
# plt.ylabel('bool :: is_clfd')
# plt.legend()
# plt.show()

