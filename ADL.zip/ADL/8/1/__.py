import os
import pandas as pd
import matplotlib.pyplot as plt
import dill

os_cwd = os.getcwd()

dil__nn__01 = '__/0/_01_.dil'
io_p_pklio0uc = '__/0/io_0__urls_cords.pkl'
io_p_pklio1uc = '__/0/io_1__urls_cords.pkl'



_01_ = dill.load(open(dil__nn__01, 'rb'))

if(not os.path.exists(io_p_pklio1uc)):
    pd_pkl__io1uc = pd.DataFrame.from_dict({"urls":[],"cords":[],"is_clfd":[]},orient='columns')
    pd.to_pickle(pd_pkl__io1uc,io_p_pklio1uc)
pd_pkl__io1uc = pd.read_pickle(io_p_pklio1uc)

pkl_pd__io0uc = pd.read_pickle(io_p_pklio0uc)
pd_pkl_io0uc = pd.DataFrame({'urls':[],'cords':[],'is_clfd':[]}).to_dict(orient='list')
for i in range(len(pd_pkl_io0uc)):
    pd_pkl_io0uc['urls'] += [pkl_pd__io0uc[i][0]]
    pd_pkl_io0uc['cords'] += [pkl_pd__io0uc[i][1]]
    pd_pkl_io0uc['is_clfd'] += [pkl_pd__io0uc[i][2]]
pd_pkl_io0uc = pd.DataFrame.from_dict(pd_pkl_io0uc,orient='columns')



pd_pkl__io1uc = pd.read_pickle(io_p_pklio1uc)

# plt.rcParams['toolbar'] = 'None'
plt.rcParams['font.family'] = 'monospace'
fig__io1uc, ax__io1uc = plt.subplots()
ax__io1uc.plot(list(pd_pkl__io1uc.index[pd_pkl__io1uc['is_clfd'] == 0]), list(pd_pkl__io1uc[pd_pkl__io1uc['is_clfd'] == 0]['is_clfd']), 'go', label='is_clfd=0')
ax__io1uc.plot(list(pd_pkl__io1uc.index[pd_pkl__io1uc['is_clfd'] == 1]), list(pd_pkl__io1uc[pd_pkl__io1uc['is_clfd'] == 1]['is_clfd']), 'ro', label='is_clfd=1')
ax__io1uc.xaxis.set_ticks(pd_pkl__io1uc.index)
ax__io1uc.yaxis.set_ticks(pd_pkl__io1uc['is_clfd'])
ax__io1uc.tick_params(axis='x', colors='white')
ax__io1uc.tick_params(axis='y', colors='white')
ax__io1uc.spines['bottom'].set_color('white')
ax__io1uc.spines['top'].set_color('white') 
ax__io1uc.spines['right'].set_color('white')
ax__io1uc.spines['left'].set_color('white')
ax__io1uc.set_xlabel('index :: [urls, cords]', color='white')
ax__io1uc.set_ylabel('bool :: is_clfd', color='white')
ax__io1uc.legend()
fig__io1uc.patch.set_facecolor('black')
ax__io1uc.set_facecolor('black')
fig__io1uc.savefig(str(os_cwd+"/__/0/plt__io1uc.png"))