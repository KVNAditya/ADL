document.addEventListener('DOMContentLoaded', function() {
    $('#div_id__00').show();
    $('#div_id__01').hide();
    $('#div_id__02').hide();
    commit();
}, false);


$(function() {
    $('#iab_id__00').on('click', function(e) {
        e.preventDefault();
        $('#div_id__00').show();
        $('#div_id__01').hide();
        $('#div_id__02').hide();
        commit();
    });
});

$(function() {
    $('#iab_id__01').on('click', function(e) {
        e.preventDefault();
        $('#div_id__01').show();
        $('#div_id__00').hide();
        $('#div_id__02').hide();
        commit();
    });
});

$(function() {
    $('#iab_id__02').on('click', function(e) {
        e.preventDefault();
        $('#div_id__02').show();
        $('#div_id__00').hide();
        $('#div_id__01').hide();
        commit();
    });
});