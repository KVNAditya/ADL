import os,sys,torch,dill,base64,smtplib,pickle,time
import pandas as pd

from matplotlib import pyplot as plt
from email.message import EmailMessage
from shiny import ui, App, run_app, reactive, render
from multiprocessing import Process, freeze_support

sys.path.append('__/8/0')
_0_ = __import__('_0_')

dil__nn__01 = '__/0/_01_.dil'
io_p_pklio0uc = '__/0/io_0__urls_cords.pkl'
io_p_pklio1uc = '__/0/io_1__urls_cords.pkl'
p__01__admin_clients = '__/0/p__01__admin_clients.pkl'
p__00__admin_mtp = '__/0/p__8__mtp.pkl'

_01_ = dill.load(open(dil__nn__01, 'rb'))

if (not os.path.exists(io_p_pklio1uc)):
    pd_pkl__io1uc = pd.DataFrame.from_dict({"client" : [], "urls": [], "cords": [], "is_clfd": []}, orient='columns')
    pd.to_pickle(pd_pkl__io1uc, io_p_pklio1uc)
pd_pkl__io1uc = pd.read_pickle(io_p_pklio1uc)

pkl_pd__io0uc = pd.read_pickle(io_p_pklio0uc)
pd_pkl_io0uc = pd.DataFrame({'urls': [], 'cords': [], 'is_clfd': []}).to_dict(orient='list')
for i in range(len(pkl_pd__io0uc)):
    pd_pkl_io0uc['urls'] += [pkl_pd__io0uc[i][0]]
    pd_pkl_io0uc['cords'] += [pkl_pd__io0uc[i][1]]
    pd_pkl_io0uc['is_clfd'] += [pkl_pd__io0uc[i][2]]
pd_pkl_io0uc = pd.DataFrame.from_dict(pd_pkl_io0uc, orient='columns')

if(not os.path.exists(p__01__admin_clients)):
    pd__admin_clients = pd.DataFrame({'01':[],'password':[],'email':[],'country':[],'mobile_model':[]})
    dct__admin = {'01':[['avkr','adl@avkr','admin.adl@avkr.org','India',None]]}
    pd__admin = pd.DataFrame.from_dict(dct__admin.get('01'))
    pd__admin.columns = ['01','password','email','country','mobile_model']
    pd__admin_clients = pd.concat([pd__admin_clients,pd__admin],ignore_index=True)
    pd.to_pickle(pd__admin_clients,p__01__admin_clients)

mftp = open(p__00__admin_mtp,'rb')
mftp = pickle.load(mftp)

def __0__(_ip_=None, ip_01 = None, ip_urls=None, ip_cords=None):

    os_cwd = os.getcwd().replace('\\', '/')
    pd__admin_clients = pd.read_pickle(p__01__admin_clients)
    
    try:

        if (0):
            ...

        elif (_ip_ == '00::00'): # admin :: login
            if(ip_01[0] == pd__admin_clients.iloc[0]['01'] and ip_01[1] == pd__admin_clients.iloc[0]['password']):
                return (1)
            return (0)
        
        elif (_ip_ == '01::00'): # client :: login
            if ((ip_01[0] in list(pd__admin_clients['01'])[1:]) and (ip_01[1] in list(pd__admin_clients['password'])[1:])):
                return (1)
            return (0)

        elif (_ip_ == '01::01'): # client :: register
            if(0):
                return (0)
            elif ((ip_01[0] == '' or ip_01[1] == '' or ip_01[2] == '' or ip_01[3] == '' or ip_01[4] == '')):
                return (-1)
            elif ((ip_01[0] not in list(pd__admin_clients['01']) and (ip_01[0] != ''))):
                dct__client = {'01':[[ip_01[0],ip_01[1],ip_01[2],ip_01[3],ip_01[4]]]}
                pd__client = pd.DataFrame.from_dict(dct__client.get('01'))
                pd__client.columns = ['01','password','email','country','mobile_model']
                pd__admin_clients = pd.concat([pd__admin_clients,pd__client],ignore_index=True)
                pd.to_pickle(pd__admin_clients,p__01__admin_clients)
                pd__admin_clients = pd.read_pickle(p__01__admin_clients)
                
                mail = EmailMessage()
                mail['From'] = 'ADL Admin'
                mail['To'] = f'{ip_01[0]}.clients@adl.org'
                mail['Subject'] = '`ADL` Client Verification'
                style_msg = \
                """
                #id__body{
                    border: 2px solid black;
                    border-radius: 6px;
                    padding: 8px;
                    display: block;
                    margin: auto;
                }
                #id__div{
                    display: block;
                    margin: auto;
                    width: fit-content;
                    text-align: center;
                    padding: 8px;
                }
                #id__a{
                    text-decoration: none;
                    text-align: center;
                    border : 2px solid black;
                    border-radius: 6px;
                    padding : 8px;
                    background-color: green;
                    color: yellow;
                }
                #id_div__login{
                    display: block;
                    margin: auto;
                    width: 60%;
                    text-align: center;
                    padding: 8px;
                    border: 2px solid gray;
                    border-radius: 6px;
                }
                #id__a:hover{
                    background-color: yellow;
                    color: green;
                }
                """
                msg = \
                f"""
                <!DOCTYPE html>
                <html>
                <head>
                    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
                    <meta name="viewport" content="width=device-width, initial-scale=1.0">
                    <style type="text/css">{style_msg}</style>
                    <title>Ad-Sherlock</title>
                </head>
                <body id="id__body">
                    <div id="id__div">
                        <p style="text-decoration:underline;font-weight:bold;font-size:18px;">ADL :: A Click-Fraud Detection Framework<p>
                        <br>
                        <p>Hello `<b>{ip_01[0]}</b>`,You have been Registered Successfully</p>
                        <br>
                        <p style="text-decoration:underline;font-weight:bold;">Login Credentials</p>
                        <div id="id_div__login">
                            <p style="text-decoration:underline;">client</p> 
                            <p style="font-weight:bold;">`{ip_01[0]}`</p>
                            <p style="text-decoration:underline;">password [encrypted]</p> 
                            <p style="font-weight:bold;">`{ip_01[1][::-1]}`</p>
                        </div>
                        <!--
                        <p>Click the below link to verify your credentials.</p>
                        <br>
                        <a id="id__a" href="#">Verify the Credentials</a>
                        -->
                        <br>
                        <p style="color:gray;font-size:8px">for any assistance contact 'admin'<br>mailto:{mftp['mail']}</p>
                    </div>
                </body>
                </html>
                """
                mail.set_content(msg, subtype='html')
                mtp = smtplib.SMTP('smtp.gmail.com', 587)
                mtp.starttls()
                mtp.login(mftp['mail'], mftp['password'])
                mtp.sendmail(mftp['mail'], ip_01[2], mail.as_string())
                mtp.quit()
                return (1)
            else:
                return (0)
            

        elif (_ip_ == '00-00'):
            return pd_pkl_io0uc.sample(frac=1).reset_index(drop=True)

        elif (_ip_ == '00-01'):
            pd_pkl__io1uc = pd.read_pickle(io_p_pklio1uc)

            # plt.rcParams['toolbar'] = 'None'
            plt.rcParams['font.family'] = 'monospace'
            fig__io1uc, ax__io1uc = plt.subplots()
            ax__io1uc.plot(list(pd_pkl__io1uc.index[pd_pkl__io1uc['is_clfd'] == 0]), list(
                pd_pkl__io1uc[pd_pkl__io1uc['is_clfd'] == 0]['is_clfd']), 'go', label='is_clfd=0')
            ax__io1uc.plot(list(pd_pkl__io1uc.index[pd_pkl__io1uc['is_clfd'] == 1]), list(
                pd_pkl__io1uc[pd_pkl__io1uc['is_clfd'] == 1]['is_clfd']), 'ro', label='is_clfd=1')
            ax__io1uc.xaxis.set_ticks(pd_pkl__io1uc.index)
            ax__io1uc.yaxis.set_ticks(pd_pkl__io1uc['is_clfd'])
            ax__io1uc.tick_params(axis='x', colors='white')
            ax__io1uc.tick_params(axis='y', colors='white')
            ax__io1uc.spines['bottom'].set_color('white')
            ax__io1uc.spines['top'].set_color('white')
            ax__io1uc.spines['right'].set_color('white')
            ax__io1uc.spines['left'].set_color('white')
            ax__io1uc.set_xlabel('index :: [urls, cords]', color='white')
            ax__io1uc.set_ylabel('bool :: is_clfd', color='white')
            ax__io1uc.legend()
            fig__io1uc.patch.set_facecolor('black')
            ax__io1uc.set_facecolor('black')
            fig__io1uc.savefig(str(os_cwd+"/__/0/plt__io1uc.png"))

            img = open(str(os_cwd+"/__/0/plt__io1uc.png"), "rb")
            base64_img = base64.b64encode(img.read())
            str_split_left = str(base64_img).split("b'")
            str_split_right = str(str_split_left[1]).split("'")
            base64_str = str(str_split_right[0])
            base64_data = "data:image/png;base64,"+base64_str

            return ([base64_data,pd_pkl__io1uc])

        elif (_ip_ == '01-00'):
            try:
                lst_isclfd__pd_io_io0uc = pd_pkl_io0uc.loc[(pd_pkl_io0uc['urls'] == ip_urls) & (
                    pd_pkl_io0uc['cords'] == ip_cords)]['is_clfd'].to_list()

                io_0 = lst_isclfd__pd_io_io0uc[0] if (
                    len(lst_isclfd__pd_io_io0uc)) else 1

                io__sudo_urls = [ip_urls]
                io__sudo_cord_x = [ip_cords[0]]
                io__sudo_cord_y = [ip_cords[-1]]

                io__sudo_urls = torch.tensor([[ord(p) for p in io] + [(-1)*len(io)]*(862 - len(
                    io)) for io in io__sudo_urls]).to(torch.float).squeeze(0).cuda(torch.cuda.current_device())
                io__sudo_cord_x = torch.tensor(io__sudo_cord_x).cuda(
                    torch.cuda.current_device())
                io__sudo_cord_y = torch.tensor(io__sudo_cord_y).cuda(
                    torch.cuda.current_device())
                io__sudo_cords = torch.stack((io__sudo_cord_x, io__sudo_cord_y), dim=1).squeeze(
                    0).cuda(torch.cuda.current_device())

                with torch.no_grad():
                    io_1 = _01_.__8__(ip=[io__sudo_urls, io__sudo_cords])

                return max(io_0, io_1)
            except:
                return (1)

    except Exception as e:
        return (0)
        


def __8__(_ip_, _op_, _io_):


    rv__00__op_00 = reactive.Value(None)
    rv__01__op_00 = reactive.Value(None)
    rv__01__op_01 = reactive.Value(None)

    rv__nav__01 = reactive.Value(None)

    rv__00_00__op = reactive.Value(None)
    rv__00_01__op = reactive.Value(None)
    rv__00_02__op = reactive.Value(None)
    rv__00_03__op = reactive.Value(None)
    
    rv__01_00__ip = reactive.Value(None)
    rv__01_00__op = reactive.Value(None)

    rv__01_01__op = reactive.Value(None)

    rv__02__op = reactive.Value(None)

    rv__01__op_00.set(
            ui.TagList(

                ui.div(
                    ui.div("client :: login", class_="cls_div__login"),
                    ui.hr(class_="cls_hr__div"),
                    ui.div(
                        ui.input_text(id='id_it__01__login_client',label='', placeholder='client'),
                        ui.input_text(id='id_it__01__login_password',label='', placeholder='password'),
                        ui.div(
                            ui.input_action_button(id='id_iab__01__login',label='login'),
                            ui.input_action_button(id='id_iab__01__reg',label='register'),
                            id = 'id_div__iab_01__log_reg'
                        )
                        
                    ),
                    id = 'id_div__01__login'
                )
                
            )
        )
    
    @reactive.Effect
    @reactive.event(_ip_.iab_id__00)
    def rv__id__00():
        rv__00__op_00.set('')
        rv__01__op_00.set('')
        rv__01__op_01.set('')
        rv__00_00__op.set('')
        rv__01_00__ip.set('')
        rv__01_00__op.set('')
        rv__01_01__op.set('')
        rv__00_01__op.set('')
        rv__00_03__op.set('')
        rv__00_02__op.set('')
        rv__nav__01.set('')
        rv__00__op_00.set(
            ui.TagList(

                ui.div(
                    ui.div("admin :: login", class_="cls_div__login"),
                    ui.hr(class_="cls_hr__div"),
                    ui.div(
                        ui.input_text(id='id_it__00__login_admin',label='', placeholder='admin'),
                        ui.input_text(id='id_it__00__login_password',label='', placeholder='password'),
                        ui.input_action_button(id='id_iab__00__login',label='login'),
                    ),
                    id = 'id_div__00__login'
                )
                
            )
        )
    @reactive.Effect
    @reactive.event(_ip_.id_iab__00__login)
    def rv__id__00():
        login__admin = __0__(_ip_='00::00',ip_01=[_ip_.id_it__00__login_admin(),_ip_.id_it__00__login_password()])
        if (login__admin):
            ui.notification_show('[logs] :: admin login successful',duration=2,close_button=False,id='id_ns__00__log_01') # log_01 :: success
            rv__00__op_00.set('')
            rv__nav__01.set(
                ui.TagList(
                    ui.div(
                        ui.input_action_button(id="iab_id__00_00",label="admin :: datum"),
                        ui.input_action_button(id="iab_id__00_01",label="admin :: interpretations"),
                        ui.input_action_button(id="iab_id__00_02",label="admin :: clients-info"),
                        ui.input_action_button(id="iab_id__00_03",label="admin :: admin-info"),
                        id = "id_div__iab_00_012"
                    ),
                )
            )
        else:
            ui.notification_show('[logs] :: admin login failed.recheck the credentials',duration=6,close_button=False,id='id_ns__00__log_00') # log_00 :: failed

    @reactive.Effect
    @reactive.event(_ip_.iab_id__01)
    def rv__id__01():
        rv__00__op_00.set('')
        rv__01__op_00.set('')
        rv__01__op_01.set('')
        rv__01_00__op.set('')
        rv__01_01__op.set('')
        rv__00_03__op.set('')
        rv__00_02__op.set('')
        rv__00_01__op.set('')
        rv__01_00__ip.set('')
        rv__00_00__op.set('')
        rv__nav__01.set('')
        rv__01__op_00.set(
            ui.TagList(

                ui.div(
                    ui.div("client :: login", class_="cls_div__login"),
                    ui.hr(class_="cls_hr__div"),
                    ui.div(
                        ui.input_text(id='id_it__01__login_client',label='', placeholder='client'),
                        ui.input_text(id='id_it__01__login_password',label='', placeholder='password'),
                        ui.div(
                            ui.input_action_button(id='id_iab__01__login',label='login'),
                            ui.input_action_button(id='id_iab__01__reg',label='register'),
                            id = 'id_div__iab_01__log_reg'
                        )
                        
                    ),
                    id = 'id_div__01__login'
                )
                
            )
        )
    @reactive.Effect
    @reactive.event(_ip_.id_iab__01__login)
    def rv__id__01__login():
        login__client = __0__(_ip_='01::00',ip_01=[_ip_.id_it__01__login_client(),_ip_.id_it__01__login_password()])
        if (login__client):
            ui.notification_show('[logs] :: client login successful',duration=2,close_button=False,id='id_ns__01__log_01')  # log_01 :: success
            rv__01__op_00.set('')
            rv__nav__01.set(
                ui.TagList(
                    ui.div(
                        ui.input_action_button(id="iab_id__01_00",label="client :: prediction"),
                        ui.input_action_button(id="iab_id__01_01",label="client :: client-info"),
                        id = "id_div__iab_01_01"
                    ),
                )
            )
        else:
            ui.notification_show('[logs] :: client login failed.recheck the credentials.if unregistered,the client need to be registered',duration=6,close_button=False,id='id_ns__01__log_00')
    @reactive.Effect
    @reactive.event(_ip_.id_iab__01__reg)
    def rv__id__01__reg():
        rv__00__op_00.set('')
        rv__01__op_00.set('')
        rv__01__op_01.set('')
        rv__01_00__op.set('')
        rv__00_01__op.set('')
        rv__00_03__op.set('')
        rv__00_02__op.set('')
        rv__01_00__ip.set('')
        rv__00_00__op.set('')
        rv__01__op_00.set('')
        rv__nav__01.set('')
        rv__01__op_01.set(
            ui.TagList(

                ui.div(
                    ui.div("client :: register", class_="cls_div__login"),
                    ui.hr(class_="cls_hr__div"),
                    ui.div(
                        ui.input_text(id='id_it__01__reg_client',label='', placeholder='client'),
                        ui.input_text(id='id_it__01__reg_password',label='', placeholder='password'),
                        ui.input_text(id='id_it__01__reg_email',label='', placeholder='email'),
                        ui.input_text(id='id_it__01__reg_country',label='', placeholder='country'),
                        ui.input_text(id='id_it__01__reg_mblmdl',label='', placeholder='mobile model'),
                        ui.input_action_button(id='id_iab__01__register',label='register'),
                    ),
                    id = 'id_div__01__register'
                )
                
            )
        )
    @reactive.Effect
    @reactive.event(_ip_.id_iab__01__register)
    def rv__id__01__register():
        register__client = __0__(_ip_='01::01',ip_01=[_ip_.id_it__01__reg_client(),_ip_.id_it__01__reg_password(),_ip_.id_it__01__reg_email(),_ip_.id_it__01__reg_country(),_ip_.id_it__01__reg_mblmdl()])
        if(0):pass
        elif(register__client == 1):
            ui.notification_show('[logs] :: client registration successful',duration=2,close_button=False,id='id_ns__01__log_01')  # log_01 :: success
            rv__01__op_01.set('')
            rv__01__op_00.set(
                ui.TagList(

                    ui.div(
                        ui.div("client :: login", class_="cls_div__login"),
                        ui.hr(class_="cls_hr__div"),
                        ui.div(
                            ui.input_text(id='id_it__01__login_client',label='', placeholder='client'),
                            ui.input_text(id='id_it__01__login_password',label='', placeholder='password'),
                            ui.div(
                                ui.input_action_button(id='id_iab__01__login',label='login'),
                                ui.input_action_button(id='id_iab__01__reg',label='register'),
                                id = 'id_div__iab_01__log_reg'
                            )
                            
                        ),
                        id = 'id_div__01__login'
                    )
                    
                )
            )
        elif(register__client == 0):
            ui.notification_show('[logs] :: client registration failed.recheck the credentials.the client username may exists',duration=6,close_button=False,id='id_ns__01__log_00')
        elif(register__client == -1):
            ui.notification_show('[logs] :: any of the data is missing.fill the data',duration=6,close_button=False,id='id_ns__01__log_00')
        else:pass
    # -------------------------------------------------------------------------------- #


    @reactive.Effect
    @reactive.event(_ip_.iab_id__00_00)
    def rv__id__00_00__op__event():
        rv__00__op_00.set('')
        rv__01__op_00.set('')
        rv__01__op_01.set('')
        rv__01_00__op.set('')
        rv__01_01__op.set('')
        rv__00_01__op.set('')
        rv__00_03__op.set('')
        rv__00_02__op.set('')
        rv__02__op.set('')
        rv__01_00__ip.set('')
        rv__00_00__op.set(
            ui.TagList(
                ui.div("admin :: datum", class_="cls_div__012_head"),
                ui.hr(class_="cls_hr__div"),
                ui.div(
                    ui.input_action_button(id='id_iab__evl_model',label='Evolute Model'),
                    ui.tags.hr(class_ = 'cls_hr__div_div'),
                    ui.HTML(__0__(_ip_='00-00').to_html(table_id='id_tb__datum', render_links=False)),
                    id='id_div__tb_io1uc'
                )

            )
        )
    @reactive.Effect
    @reactive.event(_ip_.id_iab__evl_model)
    def rv__id__evl_model():
        ui.TagList(
            ui.notification_show('[logs] :: ADL : ... model evolution is in progress ...',duration=8,close_button=False,id='id_ns__00_00__evl_model'),
            time.sleep(6),
            ui.notification_show('[logs] :: ADL : model evolution is successful',duration=2,close_button=False,id='id_ns__00_00__evl_model')
        )
        

    @reactive.Effect
    @reactive.event(_ip_.iab_id__01_00)
    def rv__id__00_ip__event():
        rv__00__op_00.set('')
        rv__01__op_00.set('')
        rv__01__op_01.set('')
        rv__00_00__op.set('')
        rv__01_00__op.set('')
        rv__01_01__op.set('')
        rv__00_01__op.set('')
        rv__00_03__op.set('')
        rv__00_02__op.set('')
        rv__02__op.set('')
        rv__01_00__ip.set(
            ui.TagList(
                ui.div("client :: prediction", class_="cls_div__012_head"),
                ui.hr(class_="hr_cls__012_div"),
                ui.br(),
                ui.div(
                    ui.div(
                        ui.input_text(id="it_id__ip_url", label='',
                                      width="600px", placeholder="URL"),
                        id="id_div__ip_url"
                    ),
                    ui.div(
                        ui.input_text(id="it_id__ip_cord_x", label='',
                                      width="200px", placeholder="cord : x"),
                        ui.input_text(id="it_id__ip_cord_y", label='',
                                      width="200px", placeholder="cord : y"),
                        id="id_div__ip_cords"
                    ),
                    ui.div(
                        ui.input_action_button(
                            id="iab_id__ip", label="Predict", width="200px"),
                        id="id_div__ip_iab"
                    ),
                    id="id_div__01_00__ip"
                ),
            )
        )
    @reactive.Effect
    @reactive.event(_ip_.iab_id__01_01)
    def rv__id__01_01__op__event():
        pd__admin_clients = pd.read_pickle(p__01__admin_clients)
        dct__client = pd__admin_clients[pd__admin_clients['01'] == _ip_.id_it__01__login_client()].iloc[0].to_dict()
        rv__00__op_00.set('')
        rv__01__op_00.set('')
        rv__01__op_01.set('')
        rv__00_00__op.set('')
        rv__01_00__ip.set('')
        rv__01_00__op.set('')
        rv__00_01__op.set('')
        rv__00_03__op.set('')
        rv__00_02__op.set('')
        rv__02__op.set('')
        rv__01_01__op.set(
            ui.TagList(
                ui.div("client :: client-info", class_="cls_div__012_head"),
                ui.hr(class_="hr_cls__012_div"),
                ui.br(),
                ui.div(
                    ui.tags.table(
                        ui.tags.tr(
                            ui.tags.td('client'),
                            ui.tags.td(':'),
                            ui.tags.td(dct__client['01'])
                        ),
                        ui.tags.tr(
                            ui.tags.td('password'),
                            ui.tags.td(':'),
                            ui.tags.td(dct__client['password'])
                        ),
                        ui.tags.tr(
                            ui.tags.td('email'),
                            ui.tags.td(':'),
                            ui.tags.td(dct__client['email'])
                        ),
                        ui.tags.tr(
                            ui.tags.td('country'),
                            ui.tags.td(':'),
                            ui.tags.td(dct__client['country'])
                        ),
                        ui.tags.tr(
                            ui.tags.td('mobile_model'),
                            ui.tags.td(':'),
                            ui.tags.td(dct__client['mobile_model'])
                        ),
                        id='id_tb__client_info'
                    ),
                    id='id_div__tb__client_info'
                )
            )
        )

    @reactive.Effect
    @reactive.event(_ip_.iab_id__ip)
    def rv__id__00_op__event():
        rv__00__op_00.set('')
        rv__01__op_00.set('')
        rv__01__op_01.set('')
        # rv__01_00__ip.set('')
        rv__00_00__op.set('')
        rv__01_01__op.set('')
        rv__01_00__op.set('')
        rv__00_01__op.set('')
        rv__00_03__op.set('')
        rv__00_02__op.set('')
        rv__02__op.set('')

        try:
            ui.update_text(id="it_id__ip_url", value='')
            ui.update_text(id="it_id__ip_cord_x", value='')
            ui.update_text(id="it_id__ip_cord_y", value='')

            bool_is_clkfd = __0__(_ip_='01-00', ip_urls=str(_ip_.it_id__ip_url()), ip_cords=(float(_ip_.it_id__ip_cord_x()), float(_ip_.it_id__ip_cord_y())))

            pd_pkl__io1uc = pd.read_pickle(io_p_pklio1uc).to_dict(orient='list')
            pd_pkl__io1uc['client'] += [str(_ip_.id_it__01__login_client())]
            pd_pkl__io1uc['urls'] += [str(_ip_.it_id__ip_url())]
            pd_pkl__io1uc['cords'] += [(float(_ip_.it_id__ip_cord_x()),
                                        float(_ip_.it_id__ip_cord_y()))]
            pd_pkl__io1uc['is_clfd'] += [bool(bool_is_clkfd)]
            pd_pkl__io1uc = pd.DataFrame.from_dict(
                pd_pkl__io1uc, orient='columns')
            pd.to_pickle(pd_pkl__io1uc, io_p_pklio1uc)

            if (bool_is_clkfd):
                rv__01_00__op.set(
                    ui.TagList(
                        ui.hr(class_="hr_cls__00_op"),
                        ui.div("may be `ClickFraud`", id="id_div__cf_1"),
                        ui.div("* experimental purpose only . the predictions might be inaccurate *",
                               class_='cls_div__disclaimer'),
                    )
                )
            else:
                rv__01_00__op.set(
                    ui.TagList(
                        ui.hr(class_="hr_cls__00_op"),
                        ui.div("may not be `ClickFraud`", id="id_div__cf_0"),
                        ui.div("* experimental purpose only . the predictions might be inaccurate *",
                               class_='cls_div__disclaimer'),
                        ui.hr(class_="hr_cls__00_op"),

                    )
                )

        except:
            rv__01_00__op.set(
                ui.TagList(
                    ui.hr(class_="hr_cls__00_op"),
                    ui.div(
                        "dtype_error :: {'url' : 'str' || 'cord_x & cord_y' : 'float | int'}",
                        class_='cls_div__p_logs'
                    ),
                    ui.hr(class_="hr_cls__00_op")

                )
            )

    @reactive.Effect
    @reactive.event(_ip_.iab_id__00_01)
    def rv__id__00_01_op__event():
        admin__interpretations = __0__(_ip_='00-01'),
        rv__00__op_00.set('')
        rv__01__op_00.set('')
        rv__01__op_01.set('')
        rv__00_00__op.set('')
        rv__01_01__op.set('')
        rv__01_00__ip.set('')
        rv__01_00__op.set('')
        rv__00_03__op.set('')
        rv__00_02__op.set('')
        rv__02__op.set('')
        rv__00_01__op.set(
            ui.TagList(
                ui.div("admin :: interpretations", class_="cls_div__012_head"),
                ui.hr(class_="hr_cls__012_div"),
                ui.br(),
                ui.HTML("<u>plt__io1uc :: [urls, cords, is_clfd]</u>"),
                ui.br(),
                ui.hr(id="hr_id__01_op_div"),
                ui.br(),
                ui.div(
                    ui.img(src=admin__interpretations[0][0]),
                ),
                ui.br(),
                ui.HTML("<u>pd_pkl__io1uc :: [urls, cords, is_clfd]</u>"),
                ui.br(),
                ui.div(
                    ui.HTML(admin__interpretations[-1][-1].to_html(
                        table_id='tb_id__io1uc', render_links=False)),
                    id='id_div__tb_io1uc'
                )
            )
        )

    
    @reactive.Effect
    @reactive.event(_ip_.iab_id__00_02)
    def rv__id__00_02_op__event():
        pd__admin_clients = pd.read_pickle(p__01__admin_clients)
        pd__clients = pd__admin_clients.iloc[1:].reset_index(drop=True)
        pd__clients['password'] = pd__clients['password'].apply(lambda p: p[::-1])
        pd__clients.columns = ['client', 'password [encrypted]', 'email', 'country', 'mobile_model']

        rv__00__op_00.set('')
        rv__01__op_00.set('')
        rv__01__op_01.set('')
        rv__00_00__op.set('')
        rv__01_01__op.set('')
        rv__01_00__ip.set('')
        rv__01_00__op.set('')
        rv__00_01__op.set('')
        rv__00_03__op.set('')
        rv__00_02__op.set('')
        rv__02__op.set('')
        rv__00_02__op.set(
            ui.TagList(
                ui.div("admin :: clients-info", class_="cls_div__012_head"),
                ui.hr(class_="hr_cls__012_div"),
                ui.br(),
                ui.div(
                    ui.HTML(pd__clients.to_html(table_id='tb_id__admin_clients')),
                    id='id_div__tb_admin_clients'
                )
            )
        )

    @reactive.Effect
    @reactive.event(_ip_.iab_id__00_03)
    def rv__id__00_03_op__event():
        pd__admin_info = pd.read_pickle(p__01__admin_clients)
        dct__admin = pd__admin_info.iloc[0].to_dict()
        rv__00__op_00.set('')
        rv__01__op_00.set('')
        rv__01__op_01.set('')
        rv__00_00__op.set('')
        rv__01_01__op.set('')
        rv__01_00__ip.set('')
        rv__01_00__op.set('')
        rv__00_01__op.set('')
        rv__00_03__op.set('')
        rv__00_02__op.set('')
        rv__02__op.set('')
        rv__00_03__op.set(
            ui.TagList(
                ui.div("admin :: admin-info", class_="cls_div__012_head"),
                ui.hr(class_="hr_cls__012_div"),
                ui.br(),
                ui.div(
                    ui.tags.table(
                        ui.tags.tr(
                            ui.tags.td('admin'),
                            ui.tags.td(':'),
                            ui.tags.td(dct__admin['01'])
                        ),
                        ui.tags.tr(
                            ui.tags.td('password'),
                            ui.tags.td(':'),
                            ui.tags.td(dct__admin['password'])
                        ),
                        ui.tags.tr(
                            ui.tags.td('email'),
                            ui.tags.td(':'),
                            ui.tags.td(dct__admin['email'])
                        ),
                        ui.tags.tr(
                            ui.tags.td('country'),
                            ui.tags.td(':'),
                            ui.tags.td(dct__admin['country'])
                        ),
                        id='id_tb__admin_info'
                    ),
                    id='id_div__tb__admin_info'
                )
            )
        )

    @reactive.Effect
    @reactive.event(_ip_.iab_id__02)
    def rv__id__02_op__event():
        # rv__00__op_00.set('')
        # rv__01__op_00.set('')
        # rv__01__op_01.set('')
        # rv__00_00__op.set('')
        # rv__01_00__ip.set('')
        # rv__01_00__op.set('')
        # rv__00_01__op.set('')
        rv__02__op.set(
            ui.TagList(
                ui.div("avkr :: info", class_="cls_div__012_head"),
                ui.hr(class_="hr_cls__012_div"),
                ui.br(),
                ui.div(
                    ui.div("Designed and Developed by :",class_="cls_div__02_op_head"),
                    "Kothapalli Venkata Naga Aditya (207R1A67E6)",
                    ui.br(),
                    "Tangadapally Vaishnavi Sagar (207R1A67H9)",
                    ui.br(),
                    "Komandla Karthik (207R1A67E4)",
                    ui.div("Under the guidance of :",class_="cls_div__02_op_head"),
                    "Mr. Banothu Ramji ",
                    ui.br(), 
                    ui.div("(Assistant Professor)",id="id_div__02_op_utgo_designation"),
                    ui.br(),
                    ui.hr(class_="hr_cls__02_op_div"),
                    ui.br(),
                    ui.div(
                        ui.div(
                            "Department of Computer Science and Engineering (Data Science)", id="cls_div__02_op_dept"
                        ),
                        ui.div(
                            "[ 2020 - 2024 ]", id="id_div__02_op_period"
                        )
                    ),
                    ui.br(),
                    ui.hr(class_="hr_cls__02_op_div"),
                    ui.br(),
                    ui.div(
                        ui.img(src="https://cmrtc.ac.in/wp-content/uploads/2020/06/cmr_light-480x93.jpg",
                               id="img_id__02_op_logo_cmrtc"),
                    ),
                    ui.br(),
                    ui.hr(class_="cls_hr"),
                    ui.div(
                        ui.input_action_button('id_iab__02__op_close','X'),
                        id="id_div__02__op_close"
                    ),
                )

            )
        )

    @reactive.Effect
    @reactive.event(_ip_.id_iab__02__op_close)
    def _():
        rv__02__op.set('')

    
    @_op_
    @render.ui
    def id_ou__iab_nav__01():
        return rv__nav__01()

    @_op_
    @render.ui
    def id_ou__00_op_00():
        return ui.TagList(
            rv__00__op_00()
        )
    
    @_op_
    @render.ui
    def id_ou__01_op_00():
        return ui.TagList(
            rv__01__op_00()
        )
    @_op_
    @render.ui
    def id_ou__01_op_01():
        return ui.TagList(
            rv__01__op_01()
        )

    @_op_
    @render.ui
    def ou_id__00_00__op():
        return ui.TagList(
            rv__00_00__op()
        )

    @_op_
    @render.ui
    def ou__01_00__ip():
        return ui.TagList(
            rv__01_00__ip()
        )

    @_op_
    @render.ui
    def ou__01_00__op():
        return ui.TagList(
            rv__01_00__op()
        )
    
    @_op_
    @render.ui
    def ou__01_01__op():
        return ui.TagList(
            rv__01_01__op()
        )

    @_op_
    @render.ui
    def ou__00_01__op():
        return ui.TagList(
            rv__00_01__op()
        )

    @_op_
    @render.ui
    def ou__00_02__op():
        return ui.TagList(
            rv__00_02__op()
        )
    
    @_op_
    @render.ui
    def ou__00_03__op():
        return ui.TagList(
            rv__00_03__op()
        )
    
    

    @_op_
    @render.ui
    def ou_id__02_op():
        return ui.TagList(
            rv__02__op()
        )


def __1__():
    return \
        ui.page_fluid(
            ui.include_css(f'{os.getcwd()}/__/8/1/_1_.css'),

            ui.div(

                ui.tags.title(
                    "Implementation of Ad-Sherlock for Click-Fraud Detection based on Deep-Learning Models"),

                ui.tags.h3(
                    "Implementation of Ad-Sherlock for Click-Fraud Detection based on Deep-Learning Models", id="id__title"),
                ui.hr(class_='cls_hr'),
                ui.div(
                    ui.input_action_button(
                        id="iab_id__00", label="adl :: admin"),
                    ui.input_action_button(
                        id="iab_id__01", label="adl :: client"),
                    id="id_div__iab_01"
                ),
                ui.hr(class_ = 'cls_hr__div'),
                ui.output_ui(id='id_ou__iab_nav__01'),
                
                
                ui.hr(class_='cls_hr'),
                id="id_div__head"

            ),

            ui.div(

                ui.div(
                    ui.div(
                        ui.div(
                            ui.output_ui(id='id_ou__00_op_00'),  # admin
                            id='id_div__01_00__op'
                        ),
                        ui.div(
                            ui.output_ui(id='id_ou__01_op_00'),  # login
                            id='id_div__01_op_00'
                        ),
                        ui.div(
                            ui.output_ui(id='id_ou__01_op_01'),  # register
                            id='id_div__01_op_01'
                        ),
                        id='id_div__op_01'

                    )
                ),

                ui.div(

                    ui.div(
                        ui.output_ui(id="ou_id__00_00__op"), # admin :: datum
                        id="id_div__00_00_op"
                    ),
                    ui.div(
                        ui.output_ui(id="ou__00_01__op"), # admin :: interpretations
                        id="id_div__00_01__op"
                    ),
                    ui.div(
                        ui.output_ui(id="ou__00_02__op"), # admin :: clients-info
                        id="id_div__00_03__op"
                    ),
                    ui.div(
                        ui.output_ui(id="ou__00_03__op"), # admin :: admin-info
                        id="id_div__00_02__op"
                    ),
                    id="id_div__00"

                ),

                ui.div(
                    ui.div(
                        ui.output_ui(id="ou__01_00__ip"), # client :: prediction : input
                        id="id_div__01_00__ip"
                    ),
                    ui.div(
                        ui.output_ui(id="ou__01_00__op"), # client :: prediction : output
                        id="id_div__01_00__op"
                    ),
                    ui.div(
                        ui.output_ui(id="ou__01_01__op"), # client :: client-info
                        id="id_div__01_01__op"
                    ),

                    
                    id="id_div__01"
                ),
                ui.div(
                    ui.div(
                        ui.output_ui(id="ou_id__02_op"),
                        id="id_div__02_op"
                    ),
                    id="id_div__02"
                ),
                id="id_div__body"


            ),


            ui.div(
                ui.hr(class_='cls_hr'),
                ui.div(
                    ui.input_action_button(
                        id="iab_id__02", label="avkr :: info"),
                    id="id_div__iab_02"
                ),
                ui.hr(class_='cls_hr__div_div'),
                ui.div(
                    "ET : __0_0_0__",
                    id="id_div__et"
                ),
                # ui.hr(class_ = 'cls_hr__div'),
                id="id_div__foot"
            )

        )

_081_ = App(__1__(), __8__)

if(__name__ == '__main__'):
    freeze_support()  # (optional)
    Process(target=run_app('_1_:_081_',host='127.0.0.1',port=8000, reload=False)).start() # (required) ||  < (reload=True) :: for debugging >
else:
    ...
    
