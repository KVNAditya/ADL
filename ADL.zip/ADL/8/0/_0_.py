def main():

    # _0_.ipynb

    import random,string,os,pickle,dill,torch,warnings
    import matplotlib.pyplot as plt 
    from faker import Faker
    from torch import nn

    warnings.filterwarnings("ignore")
    plt.rcParams['figure.facecolor'] = 'gray'
    plt.rcParams['axes.facecolor'] = 'gray'


    io_pklio0uc = '../../../__/0/io_0__urls_cords.pkl'
    def func_io_sudo_urls_cords(n=4*random.randrange(20,80)):
        random.seed(268862)
        Faker.seed(268862)
        fake = Faker()
        sudo_urls = [f'http://www.ads.{fake.domain_name()}' for _ in range(n//4)] + [f'https://www.ads.{fake.domain_name()}' for _ in range(n//4)] + [f'http://www.{fake.domain_name()}' for _ in range(n//4)] + [f'https://www.{fake.domain_name()}' for _ in range(n//4)]
        sudo_urls = [sudo_urls[P]+'/'+ ''.join(random.choice(random.choice(string.digits + string.ascii_letters)) for _ in range(random.randint(20, 80))) + '?' + '&'.join([f"param_{p}={''.join(random.choice(random.choice(string.digits + string.ascii_letters)) for _ in range(random.randint(20, 80)))}" for p in range(1, random.randint(2, 8) + 1)]) for P in range(len(sudo_urls))]
        random.shuffle(sudo_urls)
        sudo_isad = [1 if('ad' in i) else 0 for i in sudo_urls]
        sudo_cords = [(random.randrange(2,862268),random.randrange(2,862268)) for _ in range(n)]
        random.shuffle(sudo_cords)
        sudo_urls_cords = [(sudo_urls[p],(sudo_cords[p][0],sudo_cords[p][1]),sudo_isad[p]) for p in range(n)]
        random.shuffle(sudo_urls_cords)
        return sudo_urls_cords
    if(not os.path.exists(io_pklio0uc)):
        io__sudo_urls_cords = func_io_sudo_urls_cords(888) # n : multiples of '4'
        pickle.dump(io__sudo_urls_cords, open(io_pklio0uc, 'wb'))
    io__sudo_urls_cords = pickle.load(open(io_pklio0uc, 'rb'))
    io__sudo_urls = [p[0] for p in io__sudo_urls_cords]
    io__sudo_cord_x,io__sudo_cord_y = [p[1][0] for p in io__sudo_urls_cords],[p[1][1] for p in io__sudo_urls_cords]
    io__sudo_isad = [p[2] for p in io__sudo_urls_cords]
    for p in random.sample(io__sudo_urls_cords,4):
        ...
    def func_oi__sudo_urls_cords(oi):
        ...

    io__sudo_urls = torch.tensor([[ord(p) for p in io] + [(-1)*len(io)]*(862 - len(io)) for io in io__sudo_urls]).to(torch.float).cuda(torch.cuda.current_device())
    io__sudo_cord_x = torch.tensor(io__sudo_cord_x).cuda(torch.cuda.current_device())
    io__sudo_cord_y = torch.tensor(io__sudo_cord_y).cuda(torch.cuda.current_device())
    io__sudo_cords = torch.stack((io__sudo_cord_x,io__sudo_cord_y),dim=1).cuda(torch.cuda.current_device())
    io__sudo_isad = torch.tensor(io__sudo_isad).cuda(torch.cuda.current_device())

    class __01__(nn.Module):
        def __init__(IO):
            super().__init__()
            IO._O_ = torch.zeros(1).unsqueeze(0).to(torch.float).cuda(torch.cuda.current_device())
            IO._I_ = torch.ones(1).unsqueeze(0).to(torch.float).cuda(torch.cuda.current_device())
            IO.l20 = nn.Linear(862,1)
            IO.l21 = nn.Linear(2,1)
            IO.l30 = nn.Bilinear(1,1,1)
            IO.l31 = nn.Bilinear(1,1,1)
            IO.l40 = nn.Identity()
            IO.l41 = nn.Identity()   
            IO.l5 = nn.Sigmoid()
            IO.h20 = torch.zeros(1).unsqueeze(0).to(torch.float).cuda(torch.cuda.current_device())
            IO.h21 = torch.zeros(1).unsqueeze(0).to(torch.float).cuda(torch.cuda.current_device())
            IO.h22 = torch.zeros(1).unsqueeze(0).to(torch.float).cuda(torch.cuda.current_device())
            IO.h23 = torch.zeros(1).unsqueeze(0).to(torch.float).cuda(torch.cuda.current_device())
            IO.h30 = torch.zeros(1).unsqueeze(0).to(torch.float).cuda(torch.cuda.current_device())
            IO.h31 = torch.zeros(1).unsqueeze(0).to(torch.float).cuda(torch.cuda.current_device())
        def __8__(IO,ip=['',(0,0)],op=0.5):
            IO.ip = ip
            IO.h00 = IO.ip
            IO.h10 = IO.l20(IO.h00[0].to(torch.float)).unsqueeze(0)
            IO.h11 = IO.l21(IO.h00[1].to(torch.float)).unsqueeze(0)
            IO.h20[op==0 or op==0.5] = IO.l30(IO.h20,IO.h10)
            IO.h21[op==0.5 or op==1] = IO.l30(IO.h21,IO.h10)
            IO.h22[op==0 or op==0.5] = IO.l31(IO.h22,IO.h11)
            IO.h23[op==0.5 or op==1] = IO.l31(IO.h23,IO.h11)
            IO.h30[op==0] = IO.l40(torch.max(IO.h20,IO._O_))
            IO.h30[op==0.5] = IO.l40(torch.max(IO.h20,IO.h21))
            IO.h30[op==1] = IO.l40(torch.max(IO.h21,IO._O_))
            IO.h31[op==0] = IO.l41(torch.max(IO.h22,IO._O_))
            IO.h31[op==0.5] = IO.l41(torch.max(IO.h22,IO.h23))
            IO.h31[op==1] = IO.l41(torch.max(IO.h23,IO._O_))
            IO.h40 = IO.l5(torch.mean(torch.stack((IO.h30,IO.h31)))).item()
            IO.op = int(IO.h40 > 0.5)
            return(IO.op)

    _01_ = __01__().cuda(torch.cuda.current_device())

def name():
    ...

if(__name__ == "__main__"):
    main()
else:
    name()